Fields in male and female
- MID                   Unique integer
- FirstName             String
- MiddleName            String
- LastName  	        String
- DoB                   Date (YYYY-MM-DD)
- Country               String, DENMARK, CAN
- Short name country    String

Fields in refs (both male/female, note note the same number of males/females)
- MID                   Unique integer
- FirstName             String
- MiddleName            String
- LastName  	        String
- DoB                   Date (YYYY-MM-DD)
- Country               String, DENMARK, CAN
- Short name country    String
- LicenseGot            Date (YYYY-MM-DD)
- LicenseRenewal        Date (YYYY-MM-DD)
