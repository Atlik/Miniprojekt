﻿using System;

namespace MiniProjekt
{
    /* Dette projekt er lavet af Christian og Ferdinand
     * 
     * Beskrivelse af projektet...
     * 
     * Christian Gundersen Holmgaard,   studie nr. 20155309
     * Ferdinand Brødløs,               studie nr. 20167752
     */
    class Program 
    {
        static void Main(string[] args)
        {
            var match = new TennisMatch();
            Console.WriteLine(match);
        }
    }
}
